- Entiti datasets:

The entity datasets are in "Etrain.txt", "Edev.txt", and "Etest.txt" files. 
Format for each line in the files is:

entity_freebase_mid <TAB> notable_type <TAB> all_types (space-separated) <TAB>####<TAB> name1 freqOfName1 name2 freqOfName2 ...


- Types:

File "types.txt" contains the set of 102 FIGER types that our entities are tagged with. 







